# Ai-and-machine-learning-
Ai and machine learning 
